#include "receiver.h"
#include <vector>
using namespace std;
struct info
{
    std::string name;
    int trade_p;
    int sell_p = 2147483647;
    int buy_p = -2147483647;
};

info *stock_search(const std::string &target, vector<info *> &stock_info)
{
    for (info *item : stock_info)
    {
        if (item->name == target)
        {
            return item;
        }
    }
    return nullptr; // return nullptr if not found
}
int main(int argc, char *argv[])
{

    Receiver rcv;
    sleep(5);
    string message = rcv.readIML();

    std::istringstream iss(message);
    std::string line;
    vector<info *> stock_info;
    while (getline(iss, line, '#'))
    {
        if (line == "$")
        {
            break;
        }
        istringstream line_stream(line);
        string stockName, action;
        int price;
        line_stream >> stockName >> price >> action;
        info *result = stock_search(stockName, stock_info);
        if (result)
        {
            if (action == "s")
            {
                if (price == result->buy_p)
                {

                    result->trade_p = price;
                    result->buy_p = -2147483647;
                    if (price < result->sell_p)
                    {
                        result->sell_p = +2147483647;
                    }
                    cout << "No Trade" << endl;

                    continue;
                }
                else if (price < result->trade_p)
                {

                    result->trade_p = price;
                    cout << stockName << " " << price << " b" << endl;
                }

                else
                {
                    if (result->sell_p > price)
                    {
                        result->sell_p = price;
                    }
                    cout << "No Trade" << endl;
                }
            }

            if (action == "b")
            {
                if (price == result->sell_p)
                {

                    result->trade_p = price;
                    result->sell_p = +2147483647;
                    if (price > result->buy_p)
                    {
                        result->buy_p = -2147483647;
                    }
                    cout << "No Trade" << endl;

                    continue;
                }
                else if (price > result->trade_p)
                {
                    result->trade_p = price;
                    cout << stockName << " " << price << " s" << endl;
                }

                else
                {
                    if (result->buy_p < price)
                    {
                        result->buy_p = price;
                    }
                    cout << "No Trade" << endl;
                }
            }
        }

        else
        {
            info *new_stock = new info;
            new_stock->name = stockName;
            new_stock->trade_p = price;

            if (action == "s")
            {
                action = "b";
            }
            else
            {
                action = "s";
            }

            stock_info.push_back(new_stock);
            cout << new_stock->name << " " << price << " " << action << endl;
        }

        // Process components: stockName, price, and action
    }
    for (info *item : stock_info)
    {
        delete item;
    }

    return 0;
}
