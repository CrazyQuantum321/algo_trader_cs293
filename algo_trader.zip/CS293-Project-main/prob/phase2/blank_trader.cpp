//---------------------------------------
// DO NOT MODIFY THIS FILE
//---------------------------------------

#include <string>

int reader(int time)
{
    return 1;
}

int trader(std::string *message)
{
    return 1;
}
