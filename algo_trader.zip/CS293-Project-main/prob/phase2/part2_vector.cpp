#include "receiver.h"
#include <vector>
#include <unordered_set>
using namespace std;

using namespace std;
struct StockInfo
{
    string name;
    int quantity;

    StockInfo(string stockName, int stockQuantity)
        : name(stockName), quantity(stockQuantity) {}
};
struct Path
{
    vector<StockInfo> stocks;
    int netPrice;
    unordered_set<int> lineHashes;
    Path() : netPrice(0) {}

    void addStock(const string &name, int quantity, bool negateQuantities = false)
    {
        if (negateQuantities)
        {
            quantity = -quantity;
        }
        // Check if the stock already exists
        for (auto &stock : stocks)
        {
            if (stock.name == name)
            {
                stock.quantity += quantity;
                return;
            }
        }
        // If it does not exist, add new stock info
        stocks.emplace_back(name, quantity);
    }
    bool allQuantitiesZero() const
    {
        for (auto i : stocks)
        {
            if (i.quantity != 0)
            {
                return false;
            }
        }
        return true;
    }

    // Helper function to check if a path is valid (not containing any used lines)

    void printPath() const
    {
        for (const auto &stock : stocks)
        {
            cout << "Stock: " << stock.name << ", Quantity: " << stock.quantity << endl;
        }
        cout << "Net Price: " << netPrice << endl;
    }
};
bool isValidPath(const Path &path, const unordered_set<int> &usedLines)
{
    for (int hash : path.lineHashes)
    {
        if (usedLines.find(hash) != usedLines.end())
        {
            return false;
        }
    }
    return true;
}
void processInput(vector<Path> &paths, const string &inputLine, int lineNumber, unordered_set<int> &usedLines, vector<string> inputLines)
{
    stringstream ss(inputLine);
    string token;
    Path newPath;
    vector<string> tokens;

    // Parse inputLine into newPath object
    while (ss >> token)
    {
        if (token == "b#" || token == "s#")
            break;
        string name = token;
        int quantity;
        ss >> quantity;
        newPath.addStock(name, quantity);
    }
    ss >> newPath.netPrice;
    newPath.lineHashes.insert(lineNumber);

    // Check if newPath is a zero path or part of an existing path
    if (newPath.allQuantitiesZero())
    {
        // Output the input lines in reverse order
        cout << "Zero quantity path found: " << endl;
        for (int hash : newPath.lineHashes)
        {
            usedLines.insert(hash); // Mark the lines as used
            // Output the corresponding line in reverse order
            cout << inputLines[inputLines.size() - 1 - hash] << endl;
        }
        cout << endl;
    }
    else
    {
        // Check all existing paths and combine them with the new path if they are valid
        vector<Path> newPaths;
        for (Path &existingPath : paths)
        {
            if (isValidPath(existingPath, usedLines))
            {
                Path combinedPath = existingPath;
                for (const StockInfo &si : newPath.stocks)
                {
                    combinedPath.addStock(si.name, si.quantity);
                }
                combinedPath.netPrice += newPath.netPrice;
                // Combine the hashes from both paths
                combinedPath.lineHashes.insert(newPath.lineHashes.begin(), newPath.lineHashes.end());
                if (combinedPath.allQuantitiesZero())
                {
                    // If the combined path is a zero path, output and mark as used
                    cout << "Zero quantity combined path found: " << endl;
                    for (int hash : combinedPath.lineHashes)
                    {
                        usedLines.insert(hash);
                        cout << inputLines[inputLines.size() - 1 - hash] << endl;
                    }
                    cout << endl;
                }
                else
                {
                    newPaths.push_back(combinedPath);
                }
            }
        }
        // Add the new paths to the existing paths
        paths.insert(paths.end(), newPaths.begin(), newPaths.end());
        // If the new path is valid, add it as well
        if (isValidPath(newPath, usedLines))
        {
            paths.push_back(newPath);
        }
    }
};

Path parseInput(const string &input)
{
    stringstream ss(input);
    string token;
    Path path;
    vector<string> tokens;

    // Split input based on spaces and store in tokens
    while (getline(ss, token, ' '))
    {
        tokens.push_back(token);
    }

    // Check for 's#' at the end to determine if we should negate quantities
    bool negateQuantities = tokens.back() == "s#";

    // Parse the tokens into stock names and quantities
    for (size_t i = 0; i < tokens.size() - 2; i += 2)
    { // skip last two tokens (price and delimiter)
        string name = tokens[i];
        int quantity = stoi(tokens[i + 1]);
        path.addStock(name, quantity, negateQuantities);
    }

    // Last but one token is the net price
    path.netPrice = stoi(tokens[tokens.size() - 2]);

    return path;
}
void addNewPathToExistingPaths(vector<Path> &path_vector, const string &input)
{
    // Parse the new input into a Path object.
    Path newPath = parseInput(input);

    // Calculate the size outside the loop to avoid recomputing it
    // as it will change when new elements are added.
    size_t originalSize = path_vector.size();

    // Iterate over the existing paths and add the new path to them.
    for (size_t i = 0; i < originalSize; ++i)
    {
        Path updatedPath = path_vector[i]; // Make a copy of the current Path

        // Add each StockInfo from newPath to the updated path
        for (const StockInfo &stock : newPath.stocks)
        {
            updatedPath.addStock(stock.name, stock.quantity);
        }

        // Adjust the net price
        updatedPath.netPrice += newPath.netPrice;

        // Store the updated path back in the path_vector
        path_vector.push_back(updatedPath);
    }

    // Finally, add the new path as a new entry to the vector
    path_vector.push_back(newPath);
}

int main()
{
    unordered_set<int> usedLines;
    vector<string> inputLines;
    vector<Path> path_vector;
    Receiver rcv;
    sleep(5);
    string message = rcv.readIML();
    std::istringstream iss(message);
    std::string line;
    int i = 0;
    while (getline(iss, line, '#'))
    {
        inputLines.push_back(line);
        if (line == "$")
        {
            break;
        }
        addNewPathToExistingPaths(path_vector, line);
        processInput(path_vector, inputLines[i], i, usedLines, inputLines);
        i++;
    }
}
